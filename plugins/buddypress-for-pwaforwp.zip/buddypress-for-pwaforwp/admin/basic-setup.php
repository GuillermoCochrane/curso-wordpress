<?php
/**
 * Loads the plugin files
 *
 * @since 1.0
 */
// Exit if accessed directly
if ( ! defined('ABSPATH') ) exit;
/**
 * Setup all admin panel works.
 *
 * This way no physical files have to be placed on WP root folder. Hallelujah!
 * 
 * @author PWAforWP TEAM
 *
 */
Class BP_basic_setup{

	function __construct(){
		add_action( 'admin_init', array($this, 'admin_init_cb') );
	}

	public static function pn_defaultValues(){
		return array(
			'notification_allow_request'=> 'yes',
			'notification_new_reply'=> 'yes',
			'notification_new_message'=>'yes',
			'friends_friendship_request'=>'yes',
			'friends_friendship_accepted'=>'yes',
			'groups_invite'=>'yes', //Hook not available
			'groups_group_updated'=>'yes',
			'groups_admin_promotion'=>'yes',
			'groups_membership_request'=>'yes', //Hook not available
			'membership_request_completed'=>'yes',

			);
	}

	function admin_init_cb(){

		add_settings_section('pwaforwp_buddypress_setting_section', __return_false(), array($this, 'buddypress_msg_section_cb'), 'pwaforwp_buddypress_setting_section');
	}

	function buddypress_msg_section_cb(){
		printf('<br/><p>%s</p>', esc_html__('To allow functionality of push notification with Buddypress','buddypress-for-pwaforwp'));
		echo "<style>.bppn-pwa-table{margin-bottom:15px;text-align:left;width:90%;min-width:240px;border-collapse:collapse;padding:5px}.bppn-pwa-table td,.bppn-pwa-table th{margin-bottom:15px;text-align:left;width:100%;min-width:240px;border-collapse:collapse;padding:5px 5px 5px 20px;border:1px solid}.bppn-pwa-table .options,.bppn-pwa-table th{text-align:center}</style>";
		$html = '';
		if(!class_exists('Push_Notification_Admin')){ 
			$activate_url ='';
			$class = 'not-exist';
			if(file_exists( PWAFORWP_PLUGIN_DIR."/../push-notification/push-notification.php") && !is_plugin_active('push-notification/push-notification.php') ){
				//plugin deactivated
				$class = 'pushnotification';
				$plugin = 'push-notification/push-notification.php';
				$action = 'activate';
				if ( strpos( $plugin, '/' ) ) {
					$plugin = str_replace( '\/', '%2F', $plugin );
				}
				$url = sprintf( admin_url( 'plugins.php?action=' . $action . '&plugin=%s&plugin_status=all&paged=1&s' ), $plugin );
				$activate_url = wp_nonce_url( $url, $action . '-plugin_' . $plugin );
			 }
			$html .= '<tr>
						<td class="title"><strong>'.esc_html__('Push Notification','buddypress-for-pwaforwp').'</strong> '.esc_html__('plugin is required', 'buddypress-for-pwaforwp' ).' </td>
						<td class="options">
							<span>'.esc_html__('Plugin not installed', 'buddypress-for-pwaforwp' ).'</span>
						</td>
					</tr>';
		}else{
			$html .= '<tr>
						<td class="title"><strong>'.esc_html__('Push Notification','buddypress-for-pwaforwp').'</strong> </td>
						<td class="options"><span class="dashicons dashicons-yes-alt"></span><span>'.esc_html__(' Compatibility Enabled', 'buddypress-for-pwaforwp' ).'</span></td>
					</tr>';
		}
		$all_plugins = get_plugins();
    	$active_plugins = get_option( "active_plugins" );
		$buddypress_activate = false;
		$buddyboss_activate = false;
		foreach ( $all_plugins as $plugin_path => $value ) {
        	if( $plugin_path == 'buddypress/bp-loader.php') {
	            if( in_array( $plugin_path, $active_plugins ) ) {
	               $buddypress_activate = true;
	            }
	        }
	        if( $plugin_path == 'buddyboss-platform/bp-loader.php') {
	            if( in_array( $plugin_path, $active_plugins ) ) {
	               $buddyboss_activate = true;
	            }
	        }
	    }
	
		if($buddyboss_activate != true){
				if($buddypress_activate != true){
			$plugin_name = 'buddypress';
			$html .= '<tr>
						<td class="title"><strong>'.esc_html__('BuddyPress','buddypress-for-pwaforwp').'</strong> '.esc_html__('plugin is required', 'buddypress-for-pwaforwp' ).' </td>
						<td class="options"><span>'.esc_html__('Plugin not installed', 'buddypress-for-pwaforwp' ).'</span></td>
					</tr>';
		}else{
			$html .= '<tr>
						<td class="title"><strong>'.esc_html__('BuddyPress','buddypress-for-pwaforwp').'</strong>  </td>
						<td class="options"><span class="dashicons dashicons-yes-alt"></span><span>'.esc_html__(' Compatibility Enabled', 'buddypress-for-pwaforwp' ).'</span></td>
					</tr>';
		}
		}else{
			$html .= '<tr>
						<td class="title"><strong>'.esc_html__('BuddyBoss','buddypress-for-pwaforwp').'</strong>  </td>
						<td class="options"><span class="dashicons dashicons-yes-alt"></span><span>'.esc_html__(' Compatibility Enabled', 'buddypress-for-pwaforwp' ).'</span></td>
					</tr>';
		}
		echo "<table class='bppn-pwa-table'>
				<tr>
					<th class='title'>".esc_html__('Settings', 'buddypress-for-pwaforwp')."</th>
					<th class='options'>".esc_html__('Plugin Status', 'buddypress-for-pwaforwp')."</th>
				</tr>
				$html
			  </table>";
	}
}




$bpAd = new BP_basic_setup();