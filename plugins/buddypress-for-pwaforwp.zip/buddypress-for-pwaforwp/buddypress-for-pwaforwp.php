<?php
/**
 * Plugin Name: Buddypress for PWA for WP
 * Plugin URI: https://pwa-for-wp.com/?utm_source=buddypress-pwa-plugin&utm_medium=plugin-uri
 * Description: Utilize Buddypress notification module and extends it to send push notification
 * Author: PWAforWP Team
 * Author URI: https://pwa-for-wp.com//
 * Contributors: PWAforWP Team
 * Version: 1.3.2
 * Text Domain: buddypress-for-pwaforwp
 * Domain Path: /languages
 * License: GPL v2 - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

// Exit if accessed directly
if ( ! defined('ABSPATH') ) exit;

/**
 * Buddypress for PWAforWP current version
 *
 * @since 1.0
 */
if ( ! defined( 'BUDDYPRESSS_PWAFORWP_VERSION' ) ) {
	define( 'BUDDYPRESSS_PWAFORWP_VERSION'	, '1.3.2' ); }

/**
 * Absolute path to the plugin directory. 
 * eg - /var/www/html/wp-content/plugins/buddypress-for-pwaforwp/
 *
 * @since 1.0
 */
if ( ! defined( 'BUDDYPRESSS_PWAFORWP_PATH_ABS' ) ) {
	define( 'BUDDYPRESSS_PWAFORWP_PATH_ABS'	, plugin_dir_path( __FILE__ ) ); 
}


/**
 * Link to the plugin folder. 
 * eg - https://example.com/wp-content/plugins/buddypress-for-pwaforwp/
 *
 * @since 1.0
 */
if ( ! defined( 'BUDDYPRESSS_PWAFORWP_PATH_SRC' ) ) {
	define( 'BUDDYPRESSS_PWAFORWP_PATH_SRC'	, plugin_dir_url( __FILE__ ) ); 
}

/**
 * Full path to the plugin file. 
 * eg - /var/www/html/wp-content/plugins/buddypress-for-pwaforwp/buddypress-for-pwaforwp.php
 *
 * @since 2.0
 */
if ( ! defined( 'BUDDYPRESSS_PWAFORWP_PLUGIN_FILE' ) ) {
	define( 'BUDDYPRESSS_PWAFORWP_PLUGIN_FILE', __FILE__ ); 
}

// Load everything
require_once( BUDDYPRESSS_PWAFORWP_PATH_ABS . '/loader.php' );

//Plugin Updater code starts here

// this is the URL our updater / license checker pings. This should be the URL of the site with EDD installed
define( 'BUDDYPRESSS_PWAFORWP_DATA_STORE_URL', 'http://pwa-for-wp.com/' );

// the name of your product. This should match the download name in EDD exactly
define( 'BUDDYPRESSS_PWAFORWP_DATA_ITEM_NAME', 'BuddyPress for PWAforWP' );

// the download ID. This is the ID of your product in EDD and should match the download ID visible in your Downloads list (see example below)

// the name of the settings page for the license input to be displayed
define( 'BUDDYPRESSS_PWAFORWP_LICENSE_PAGE', 'buddypress-for-pwaforwp' );
if(! defined('BUDDYPRESSS_PWAFORWP_ITEM_FOLDER_NAME')){
    $folderName = basename(__DIR__);
    define( 'BUDDYPRESSS_PWAFORWP_ITEM_FOLDER_NAME', $folderName );
}

require_once dirname( __FILE__ ) . '/updater/EDD_SL_Plugin_Updater.php'; 

function buddypress_pwaforwp_for_pwa_updater(){
   
        $selectedOption      = get_option('pwaforwp_settings',true);                
        $license_key         = isset($selectedOption['bnpwa_addon_license_key'])? $selectedOption['bnpwa_addon_license_key']:'';        
        $licensestatus       = isset($selectedOption['bnpwa_addon_license_key_status'])? $selectedOption['bnpwa_addon_license_key_status']:'';

 
// setup the updater
  $edd_updater = new BUDDYPRESSS_PWAFORWP_Data_EDD_SL_Plugin_Updater( BUDDYPRESSS_PWAFORWP_DATA_STORE_URL, __FILE__, array(
      'version'         => BUDDYPRESSS_PWAFORWP_VERSION,      // current version number
      'license'         => $license_key,             // license key (used get_option above to retrieve from DB)
      'license_status'  => $licensestatus,
      'item_name'       => BUDDYPRESSS_PWAFORWP_DATA_ITEM_NAME,      // name of this plugin
      'author'          => 'Magazine3',           // author of this plugin
      'beta'            => false,
    )
  );      
}

add_action( 'admin_init', 'buddypress_pwaforwp_for_pwa_updater', 0);

// Notice to enter license key once activate the plugin
$path = plugin_basename( __FILE__ );
   
add_action("after_plugin_row_{$path}", function( $plugin_file, $plugin_data, $status ) {
   // global $redux_builder_amp;
    
        if(! defined('BUDDYPRESSS_PWAFORWP_ITEM_FOLDER_NAME')){
            $folderName = basename(__DIR__);
            define( 'BUDDYPRESSS_PWAFORWP_ITEM_FOLDER_NAME', $folderName );
        }
        
        $selectedOption      = get_option('pwaforwp_settings', true);                        
        $licensestatus       = isset($selectedOption['bnpwa_addon_license_key_status'])? $selectedOption['bnpwa_addon_license_key_status']:'';
        $license_key         = isset($selectedOption['bnpwa_addon_license_key'])? $selectedOption['bnpwa_addon_license_key']:''; 
                        
         if(empty($license_key)){
             
            echo "<tr class='active'><td>&nbsp;</td><td colspan='3'><a href='".esc_url(  self_admin_url( 'admin.php?page=pwaforwp&tab=premium_features#bnpwa_addon_license_key' )  )."'>Please enter the license key</a> to get the <strong>latest features</strong> and <strong>stable updates</strong></td></tr>";
            
         }elseif($licensestatus=="active"){
                          
            $update_cache = get_site_transient( 'update_plugins' );
            $update_cache = is_object( $update_cache ) ? $update_cache : new stdClass();
            
            if(isset($update_cache->response[ BUDDYPRESSS_PWAFORWP_ITEM_FOLDER_NAME."/".BUDDYPRESSS_PWAFORWP_ITEM_FOLDER_NAME.".php" ]) 
                && empty($update_cache->response[ BUDDYPRESSS_PWAFORWP_ITEM_FOLDER_NAME."/".BUDDYPRESSS_PWAFORWP_ITEM_FOLDER_NAME.".php" ]->download_link) 
             )
                    
            {
               unset($update_cache->response[ BUDDYPRESSS_PWAFORWP_ITEM_FOLDER_NAME."/".BUDDYPRESSS_PWAFORWP_ITEM_FOLDER_NAME.".php" ]);
               set_site_transient( 'update_plugins', $update_cache );
            }
            
            
            
        }
    }, 10, 3 );

//Plugin Updater code ends here