=== Buddypress for PWA for WP ===
Contributors: PWAforWP Team
Tags: PWA, buddypress, push notification, Progressive Web Apps, Mobile, Web Manifest, Manifest, Offline Support, Cache, Pagespeed, Service Worker, Web app, pwa
Requires at least: 3.0
Tested up to: 6.0
Stable tag: 1.3.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Addon for PWA for WP & AMP

== Changelog ==

= 1.3.2 (01 June 2022) =
* Added: Added BuddyBoss plugin compatible settings
* Bugfixed: Getting blank page when trying to access the BuddyBoss plugin using " Buddypress for PWAforWP " extension #704

= 1.3.1 (03 November 2021) =
* Minor changes

= 1.3 (11 August 2021) =
* Added: Added notification on basic other activities of user like on comment, message, send friendship request, accept friendship request, Group information updated etc.

= 1.2 (10 May 2021) =
* Minor changes

= 1.1 (8 May 2021) =
 Added: Compatibility with BuddyBoss platform
 Bugfixed: Removed all unused tags from notification 

= 1.0 (26 Feb 2021) =

* Version 1.0 Released