<?php
/**
 * Loads the plugin files
 *
 * @since 1.0
 */
// Exit if accessed directly
if ( ! defined('ABSPATH') ) exit;

add_action('plugins_loaded', 'bp_pwa_init');
function bp_pwa_init()
{
	// Load admin
	require_once( BUDDYPRESSS_PWAFORWP_PATH_ABS . 'admin/basic-setup.php' );
	if(!defined('PWAFORWP_PLUGIN_VERSION') || !defined('PUSH_NOTIFICATION_PLUGIN_VERSION')){
		add_action( 'admin_notices', 'bp_pwaforwp_parent_plugin_notice' );
	}else{
		$settings = pwaforwp_defaultSettings(); 
		if(isset($settings['buddypress_notification']) && $settings['buddypress_notification']==1){
			require_once( BUDDYPRESSS_PWAFORWP_PATH_ABS . 'public/notification.php' );
		}
	}
}
/**
 * Gives an message to admin if any one plugin is not exists 
 * @method bp_pwaforwp_parent_plugin_notice
 * @return Void                           
 */
function bp_pwaforwp_parent_plugin_notice(){
	if( ! defined('PWAFORWP_PLUGIN_VERSION') ){
		$class = 'notice notice-error';
		$message = esc_html__( 'Parent plugin PWA for WP & AMP not activated.', 'pull-to-refresh-for-pwa' );

		printf( '<div class="%1$s"><p>%2$s <a href="%3$s" class="button button-primary" target="__blank">Click here</a></p></div>', esc_attr( $class ),  $message , esc_url('https://wordpress.org/plugins/pwa-for-wp/') ); 
	}
	if( !defined('PUSH_NOTIFICATION_PLUGIN_VERSION') ){
		$class = 'notice notice-error';
		$message = esc_html__( 'Parent plugin Push Notification not activated.', 'pull-to-refresh-for-pwa' );

		printf( '<div class="%1$s"><p>%2$s <a href="%3$s" class="button button-primary" target="__blank">Click here</a></p></div>', esc_attr( $class ),  $message , esc_url('https://wordpress.org/plugins/push-notification/') ); 
	}

	if( !function_exists('buddypress') ){
		$class = 'notice notice-error';
		$message = esc_html__( 'BuddyPress / BuddyBoss platform compatibility plugin not activated.', 'pull-to-refresh-for-pwa' );

		printf( '<div class="%1$s"><p>%2$s <a href="%3$s" class="button button-primary" target="__blank">Click here</a></p></div>', esc_attr( $class ),  $message , esc_url('https://wordpress.org/plugins/buddypress/') ); 
	}
}