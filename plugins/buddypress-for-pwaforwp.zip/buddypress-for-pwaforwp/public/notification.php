<?php
/**
 * Public admin activity
 *
 * @since 1.0
 */
// Exit if accessed directly
if ( ! defined('ABSPATH') ) exit;

class BP_NOTIFICATION_PUBLIC{
	/**
	 * Loads the plugin files
	 *
	 * @since 1.0
	 */
	/**
	 * @method __construct
	 *
	 * initate the Pushnotification settings
	 */
	function __construct(){
		//Store token ID
		add_action('pn_tokenid_registration_id', array($this, 'store_user_registered_tokens'), 10, 5);

		add_action( 'messages_message_sent', array($this, 'bppn_messages_sent_add_notification_user'), 10, 1 );
		add_action( 'bp_activity_sent_reply_to_update_notification', array($this, 'send_notification_new_reply'), 10, 4);
		add_action( 'messages_message_sent', array($this, 'bppn_notification_new_message'), 10 );
		add_action( 'friends_friendship_requested', array($this, 'bppn_friends_friendship_request'), 10, 3 );
		add_action( 'friends_friendship_accepted', array($this, 'bppn_friends_friendship_accepted'), 10, 3 );

		//Group
		add_action( 'bp_groups_sent_updated_email', array($this, 'bppn_groups_group_updated'), 10, 4 );
		add_action( 'groups_promoted_member', array($this, 'bppn_groups_notification_promoted_member'), 10, 2 );

		add_action( 'groups_membership_accepted', array($this, 'bppn_groups_membership_request_completed'), 10, 3 );
		add_action( 'groups_membership_rejected', array($this, 'bppn_groups_membership_request_completed'), 10, 3 );


		//all setings location
		//push notification add sub menu in settings
		add_action('bp_settings_setup_nav', array($this, 'pn_sub_menu_settings'));
		
		/**
		 * Save operation for settings
		 */
		add_action( 'bp_actions', array($this, 'bp_push_notification_action_settings') );
		/**
		 * Load template
		 */
		add_filter('bp_get_template_part', array($this, 'pn_template_page'), 10, 4);

		// Set the path of the template
		add_filter('bp_get_template_stack', array($this, 'bp_add_template_path'), 10, 1);
	}
	/**
	 * @param  array all expected locations 
	 * @return array with added our new location
	 */
	function bp_add_template_path($location){
		$location[] = BUDDYPRESSS_PWAFORWP_PATH_ABS."/public/templates/";
		return $location;
	}
	/**
	 * @method pn_template_page
	 * @param  Array $templates
	 * @param  string $slug
	 * @param  string $name
	 * @param  Array $args
	 * @return Array $templates
	 */
	function pn_template_page($templates, $slug='', $name='', $args=array()){
		if(bp_current_action()=='push-notification' && $slug=='members/single/plugins'){
			$templates[0] = '/push-notification.php';
		}
		return $templates;
	}
	
	/*
	 * Add sub menu in settings panel
	 *
	 */
	
	/**
	 * @method pn_sub_menu_settings
	 * @return Void
	 *
	 * Add menu in user settings section 
	 */
	function pn_sub_menu_settings(){
		if ( ! bp_is_active( 'settings' ) ) {
			return;
		}
		// Determine user to use.
		if ( bp_displayed_user_domain() ) {
			$user_domain = bp_displayed_user_domain();
		} elseif ( bp_loggedin_user_domain() ) {
			$user_domain = bp_loggedin_user_domain();
		} else {
			return;
		}

		// Get the settings slug.
		$settings_slug = bp_get_settings_slug();
		bp_core_new_subnav_item( array(
			'name'            => _x( 'push notification', 'Profile settings sub nav', 'buddypress' ),
			'slug'            => 'push-notification',
			'parent_url'      => trailingslashit( $user_domain . $settings_slug ),
			'parent_slug'     => $settings_slug,
			'screen_function' => array($this, 'bp_pn_screen_settings'),
			'position'        => 100,
			'user_has_access' => bp_core_can_edit_settings(),
		), 'members' );
	}

	/**
	 * @method bp_push_notification_action_settings
	 * @return Void
	 *
	 * Save settings for push notification
	 */
	function bp_push_notification_action_settings(){
		// Bail if not a POST action.
		if ( ! bp_is_post_request() ) {
			return;
		}
		// Bail if no submit action.
		if ( ! isset( $_POST['push_notification-settings-submit'] ) ) {
			return;
		}
		// Bail if not in settings.
		if ( ! (bool) ( bp_is_user_settings() && bp_is_current_action( 'push-notification' ) ) ) {
			return;
		}
		// 404 if there are any additional action variables attached.
		if ( bp_action_variables() ) {
			bp_do_404();
			return;
		}

		// Nonce check.
		check_admin_referer( 'bp_push_notification_settings' );

		/**
		 * Fires before saving push_notification field visibilities.
		 *
		 * @since 1.0.0
		 */
		do_action( 'bp_push_notification_settings_before_save' );
		// Only save if there are field ID's being posted.

		if ( ! empty( $_POST['push_notifications'] ) ) {

			// Get the POST'ed field ID's.
			$posted_field_ids = $_POST['push_notifications'];
			$user_id = bp_displayed_user_id();

			$push_notificationsSettings = bp_get_user_meta( $user_id, 'bp_push_notification_setting', true );
			// Save the visibility settings.
			$updatedValues = array();
			foreach ( $posted_field_ids as $key=>$field_id ) {
				$updatedValues[sanitize_text_field($key)] = sanitize_text_field($field_id);
			}
			$push_notificationsSettings = $updatedValues;
			
			bp_update_user_meta( $user_id, 'bp_push_notification_setting', $push_notificationsSettings );

			
		}

		/**
		 * Fires after saving xprofile field visibilities.
		 *
		 * @since 2.0.0
		 */
		do_action( 'bp_push_notification_settings_after_save' );

		// Redirect to the root domain.
		bp_core_redirect( bp_displayed_user_domain() . bp_get_settings_slug() . '/push-notification' );
	}

	/**
	 * @method bp_pn_screen_settings
	 * @return Void
	 *
	 * Screen template load
	 */
	function bp_pn_screen_settings(){
		// Redirect if no privacy settings page is accessible.
		if ( bp_action_variables() || ! bp_is_current_action( 'push-notification' ) ) {
			bp_do_404();
			return;
		}
		/**
		 * Filters the template to load for the pn settings screen.
		 *
		 * @since 1.0.0
		 *
		 * @param string $template Path to the pn change avatar template to load.
		 */
		bp_core_load_template( apply_filters( 'bp_settings_screen_pn_template', '/push-notification' ) );
		
	}

	/**
	 * To store the token in db after allow
	 * @method store_user_registered_tokens
	 * @param  String                       $token_id   Generated token we get as string
	 * @param  Array                        $response   response as in Array
	 * @param  String                       $user_agent Type of browser
	 * @param  String                       $os         optional 
	 * @param  String                       $ip_address optional Grab the client ipaddress dummy
	 * @return Void                                   [description]
	 */
	function store_user_registered_tokens($token_id, $response, $user_agent, $os, $ip_address){
		$userData = wp_get_current_user();
		if(isset($userData->ID)){
		 	$userid = $userData->ID;
			$notify_data = get_user_meta($userid, 'bppn_notification_token', $response['data']['id']);
			$tokenList = array();
			if(!is_array($notify_data)){
				$tokenList[] = $notify_data;
			}else{
				$tokenList = $notify_data;
			}
			if(!in_array($response['data']['id'], $tokenList)){ $tokenList[] = $response['data']['id']; }
			update_user_meta($userid, 'bppn_notification_token', $tokenList);
		}
	}

	/**
	 * Send the push notification when any friens or person tag to the user
	 * @method bppn_messages_sent_add_notification_user
	 * @param  Array               $message  Array which contain the all details of recipent, messages etc.
	 * @return Void                                            
	 */
	function bppn_messages_sent_add_notification_user($message){
		if ( ! empty( $message->recipients ) ) {
			$notification = array();
			foreach ( (array) $message->recipients as $recipient ) {
				$user_id = $recipient->user_id;
				//Check user has allowed to send the notification or not
				$pn_allowed = bp_get_user_meta( $user_id, 'bp_push_notification_setting', true );
				if( (isset($pn_allowed['notification_allow_request']) && $pn_allowed['notification_allow_request']=='yes') || empty($pn_allowed)){
					$tokens = get_user_meta($user_id, 'bppn_notification_token', true);
					if(!is_array($tokens)){
						$notification[] = $tokens;
					}else{
						$notification = array_merge($notification, $tokens);
					}
				}

			}
			$notification = array_filter($notification);
			if(empty($notification) || !class_exists('PN_Server_Request')){
				return ;
			}
			$auth_settings = $settings = array();
			if(function_exists('pwaforwp_defaultSettings')){
				$settings 		 = pwaforwp_defaultSettings();
			}
			if(function_exists('push_notification_auth_settings')){
				$auth_settings = push_notification_auth_settings();
			}
			$user_token = '';
			if( isset( $auth_settings['user_token'] ) && !empty($auth_settings['user_token']) ){
				$user_token = $auth_settings['user_token'];
			}

			$verifyUrl = PN_Server_Request::$notificationServerUrl.'campaign/single';
			if ( is_multisite() ) {
	            $weblink = get_site_url();              
	        } else {
	            $weblink = home_url();
	        }    
			$data = array("user_token"=>$user_token,
						"audience_token_id"=>$notification,
						"title"=>wp_strip_all_tags($message->subject),
						"message"=> wp_strip_all_tags($message->message),
						"link_url"=>$weblink,
						"icon_url"=> $settings['icon'],
						"image_url"=> $settings['icon'],
						"website"=>   $weblink,
						);
			$postdata = array('body'=> $data);
			$remoteResponse = wp_remote_post($verifyUrl, $postdata);

			if( is_wp_error( $remoteResponse ) ){
				$remoteData = array('status'=>401, "response"=>"could not connect to server");
			}else{
				$remoteData = wp_remote_retrieve_body($remoteResponse);
				$remoteData = json_decode($remoteData, true);
			}

		}
	}
	/**
	 * Send the push notification when any member replies to an update or comment you've posted
	 * @method send_notification_new_reply
	 * @param  Array object           $original_activity  Object which contain the all details of thred creator.
	 * @param  String           $comment_id  id of comment.
	 * @param  String           $commenter_id  id of commenter member.
	 * @param  array           $params  Activity details.
	 * @return Void                                            
	 */
	function send_notification_new_reply($original_activity, $comment_id, $commenter_id, $params ){
		
			$notification = array();
			
				$user_id = $original_activity->user_id;
				//Check user has allowed to send the notification or not
				$pn_allowed = bp_get_user_meta( $user_id, 'bp_push_notification_setting', true );
				if( (isset($pn_allowed['notification_new_reply']) && $pn_allowed['notification_new_reply']=='yes') || empty($pn_allowed)){
					$tokens = get_user_meta($user_id, 'bppn_notification_token', true);
					if(!is_array($tokens)){
						$notification[] = $tokens;
					}else{
						$notification = array_merge($notification, $tokens);
					}
				}
			$thread_link       = bp_activity_get_permalink( $params['activity_id'] );
			$message['subject'] = esc_html__('Replied to one of your comments or update', 'buddypress-for-pwaforwp');
			$message['message'] = bp_core_get_user_displayname( $commenter_id ) . esc_html__('replied to one of your comments', 'buddypress-for-pwaforwp');
			$this->send_pwa_pn_api($notification, $message, $thread_link);
		
	}
	/*
	 *notification_new_message
	 * Send the push notification when any member sends you a new message
	 * @method bppn_notification_new_message
	 * @param  Array object           $raw_args  Object which contain the all details of thred creator.
	 * @return Void
	*/
	function bppn_notification_new_message($raw_args = array()){
		if ( is_object( $raw_args ) ) {
			$args = (array) $raw_args;
		} else {
			$args = $raw_args;
		}

		// These should be extracted below.
		$recipients    = array();
		$email_subject = $email_content = '';
		$sender_id     = 0;
		// Barf.
		extract( $args );

		if ( empty( $recipients ) ) {
			return;
		}
		if ( isset( $message ) ) {
			$message = wpautop( $message );
		} else {
			$message = '';
		}
		$notification = array();
		// Send an email to each recipient.
		foreach ( $recipients as $recipient ) {
			$user_id = $recipient->user_id;
			$pn_allowed = bp_get_user_meta( $user_id, 'bp_push_notification_setting', true );
			if( ( (isset($pn_allowed['notification_new_message']) && $pn_allowed['notification_new_message']=='yes') || empty($pn_allowed) ) && $sender_id == $recipient->user_id){

				$tokens = get_user_meta($user_id, 'bppn_notification_token', true);
				if(!is_array($tokens)){
					$notification[] = $tokens;
				}else{
					$notification = array_merge($notification, $tokens);
				}

			}
		}
		$sender_name = bp_core_get_user_displayname( $sender_id );
		$thread_link       = esc_url( bp_core_get_user_domain( $recipient->user_id ) . bp_get_messages_slug() . '/view/' . $thread_id . '/' );
		$message['subject'] = esc_html__('New message from', 'buddypress-for-pwaforwp').$sender_name;
		$message['message'] = $sender_name .' '. esc_html__(' sent you a new message ', 'buddypress-for-pwaforwp') .' '. sanitize_text_field( stripslashes( $subject ) );
		$this->send_pwa_pn_api($notification, $message, $thread_link);
	}
	/*
	 * friends_friendship_request
	 * Send the push notification when any member sends friend request
	 * @method bppn_friends_friendship_request
	 * @param  int          $friendship_id 
	 * @param  int          $initiator_id 
	 * @param  int          $friend_id 
	 * @return Void
	*/
	function bppn_friends_friendship_request( $friendship_id, $initiator_id, $friend_id ){
		$notification = array();
		$user_id = $friend_id;
		$pn_allowed = bp_get_user_meta( $user_id, 'bp_push_notification_setting', true );
		if( (isset($pn_allowed['friends_friendship_request']) && $pn_allowed['friends_friendship_request']=='yes') || empty($pn_allowed) ){

			$tokens = get_user_meta($user_id, 'bppn_notification_token', true);
			if(!is_array($tokens)){
				$notification[] = $tokens;
			}else{
				$notification = array_merge($notification, $tokens);
			}

		}
		$thread_link       = esc_url( bp_core_get_user_domain( $friend_id ) . bp_get_friends_slug() . '/requests/' );
		$message['subject'] = esc_html__('New friendship request', 'buddypress-for-pwaforwp');
		$message['message'] =bp_core_get_user_displayname( $initiator_id ) .' '. esc_html__(' wants to add you as a friend.', 'buddypress-for-pwaforwp');
		$this->send_pwa_pn_api($notification, $message, $thread_link);
	}

	/*
	 * friends_friendship_accepted
	 * Send the push notification when any member sends friend request
	 * @method bppn_friends_friendship_request
	 * @param  int          $friendship_id 
	 * @param  int          $initiator_id 
	 * @param  int          $friend_id 
	 * @return Void
	*/
	function bppn_friends_friendship_accepted( $friendship_id, $initiator_id, $friend_id ){
		$notification = array();
		$user_id = $initiator_id;
		$pn_allowed = bp_get_user_meta( $user_id, 'bp_push_notification_setting', true );
		if( (isset($pn_allowed['friends_friendship_request']) && $pn_allowed['friends_friendship_request']=='yes') || empty($pn_allowed) ){

			$tokens = get_user_meta($user_id, 'bppn_notification_token', true);
			if(!is_array($tokens)){
				$notification[] = $tokens;
			}else{
				$notification = array_merge($notification, $tokens);
			}

		}
		$thread_link       = esc_url( bp_core_get_user_domain( $friend_id ) );
		$message['subject'] = esc_html__('Accepted friendship request', 'buddypress-for-pwaforwp');
		$message['message'] =bp_core_get_user_displayname( $friend_id ) .' '. esc_html__(' accepted your friend request.', 'buddypress-for-pwaforwp');
		$this->send_pwa_pn_api($notification, $message, $thread_link);
	}

	/*
	 * groups_group_updated
	 * Send the push notification when Group information is updated
	 * @method bppn_groups_group_updated
	 * @param  int          $friendship_id 
	 * @param  int          $initiator_id 
	 * @param  int          $friend_id 
	 * @return Void
	*/
	function bppn_groups_group_updated( $user_ids, $str, $val, $group_id ){
		$group = groups_get_group( $group_id );
		$notification = array();
		foreach ( (array) $user_ids as $user_id ) {
			$pn_allowed = bp_get_user_meta( $user_id, 'bp_push_notification_setting', true );
			if( (isset($pn_allowed['groups_group_updated']) && $pn_allowed['groups_group_updated']=='yes') || empty($pn_allowed) ){

				$tokens = get_user_meta($user_id, 'bppn_notification_token', true);
				if(!is_array($tokens)){
					$notification[] = $tokens;
				}else{
					$notification = array_merge($notification, $tokens);
				}
			}

		}

		$thread_link       = esc_url( bp_get_group_permalink( $group ) );
		$message['subject'] = esc_html__('Group details updated', 'buddypress-for-pwaforwp');
		$message['message'] = $group->name.' '.esc_html__(' Group details has updated', 'buddypress-for-pwaforwp');
		$this->send_pwa_pn_api($notification, $message, $thread_link);
	}

	/*
	 * groups_admin_promotion
	 * Send the push notification when Group information is updated
	 * @method bppn_groups_notification_promoted_member
	 * @param  int          $friendship_id 
	 * @param  int          $initiator_id 
	 * @param  int          $friend_id 
	 * @return Void
	*/
	function bppn_groups_notification_promoted_member(  $user_id = 0, $group_id = 0){
		$notification = array();
		$pn_allowed = bp_get_user_meta( $user_id, 'bp_push_notification_setting', true );
		if( (isset($pn_allowed['groups_admin_promotion']) && $pn_allowed['groups_admin_promotion']=='yes') || empty($pn_allowed) ){

			$tokens = get_user_meta($user_id, 'bppn_notification_token', true);
			if(!is_array($tokens)){
				$notification[] = $tokens;
			}else{
				$notification = array_merge($notification, $tokens);
			}
		}
		$promoted_to = '';
		if ( groups_is_user_admin( $user_id, $group_id ) ) {
			$promoted_to = __( 'an administrator', 'buddypress-for-pwaforwp' );
		} else {
			$promoted_to = __( 'a moderator', 'buddypress-for-pwaforwp' );
		}
		$group = groups_get_group( $group_id );

		$thread_link       = esc_url( bp_get_group_permalink( $group ) );
		$message['subject'] = esc_html__('You have been promoted in the group:', 'buddypress-for-pwaforwp')." ".$group->name;
		$message['message'] = $group->name.' '.esc_html__(' You have been promoted to ', 'buddypress-for-pwaforwp');
		$this->send_pwa_pn_api($notification, $message, $thread_link);
	}

	/*
	 * groups_admin_promotion
	 * Send the push notification when Group information is updated
	 * @method bppn_groups_membership_request_completed
	 * @param  int          $requesting_user_id 
	 * @param  int          $group_id 
	 * @param  boolean          $accepted 
	 * @return Void
	*/
	function bppn_groups_membership_request_completed( $requesting_user_id = 0, $group_id = 0, $accepted = true ){
		$notification = array();
		$user_id = $requesting_user_id;
		$pn_allowed = bp_get_user_meta( $user_id, 'bp_push_notification_setting', true );
		if( (isset($pn_allowed['membership_request_completed']) && $pn_allowed['membership_request_completed']=='yes') || empty($pn_allowed) ){

			$tokens = get_user_meta($user_id, 'bppn_notification_token', true);
			if(!is_array($tokens)){
				$notification[] = $tokens;
			}else{
				$notification = array_merge($notification, $tokens);
			}
		}
		$group = groups_get_group( $group_id );
		
		if ( ! empty( $accepted ) ) {
			$message = esc_html__('Your membership request rejected for the group ', 'buddypress-for-pwaforwp')." ".$group->name;
		}else{
			$message = esc_html__('Your membership request accepted for the group ', 'buddypress-for-pwaforwp')." ".$group->name;
		}

		$thread_link       = esc_url( bp_get_group_permalink( $group ) );
		$message['subject'] = esc_html__('Membership request for group', 'buddypress-for-pwaforwp')." ".$group->name;
		$message['message'] = $message;
		$this->send_pwa_pn_api($notification, $message, $thread_link);
	}

	protected function send_pwa_pn_api($notification, $message, $weblink=''){
		$notification = array_filter($notification);
			if(empty($notification) || !class_exists('PN_Server_Request')){
				return ;
			}
			$auth_settings = $settings = array();
			if(function_exists('pwaforwp_defaultSettings')){
				$settings 		 = pwaforwp_defaultSettings();
			}
			if(function_exists('push_notification_auth_settings')){
				$auth_settings = push_notification_auth_settings();
			}
			$user_token = '';
			if( isset( $auth_settings['user_token'] ) && !empty($auth_settings['user_token']) ){
				$user_token = $auth_settings['user_token'];
			}

			$verifyUrl = PN_Server_Request::$notificationServerUrl.'campaign/single';
			if(empty($weblink)){
				if ( is_multisite() ) {
		            $weblink = get_site_url();              
		        } else {
		            $weblink = home_url();
		        }    
		    }
			$data = array("user_token"=>$user_token,
						"audience_token_id"=>$notification,
						"title"=>wp_strip_all_tags($message['subject']),
						"message"=> wp_strip_all_tags($message['message']),
						"link_url"=>$weblink,
						"icon_url"=> $settings['icon'],
						"image_url"=> $settings['icon'],
						"website"=>   $weblink,
						);
			$postdata = array('body'=> $data);
			$remoteResponse = wp_remote_post($verifyUrl, $postdata);

			if( is_wp_error( $remoteResponse ) ){
				$remoteData = array('status'=>401, "response"=>"could not connect to server");
			}else{
				$remoteData = wp_remote_retrieve_body($remoteResponse);
				$remoteData = json_decode($remoteData, true);
			}
	} 

}
/**
 * Object create and call the class functionality
 * @var BP_NOTIFICATION_PUBLIC
 */
$bp_public = new BP_NOTIFICATION_PUBLIC();