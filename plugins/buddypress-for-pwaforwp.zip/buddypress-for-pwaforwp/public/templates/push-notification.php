<?php
/**
 * BuddyPress - Members Settings ( Profile )
 *
 * @since 3.0.0
 * @version 3.1.0
 */
add_filter('bp_nouveau_get_submit_button', 'show_button_data');
function show_button_data($buttons){
	$buttons['member-push-notification-settings'] = array(
			'before' => 'bp_core_push_notification_settings_before_submit',
			'after'  => 'bp_core_push_notification_settings_after_submit',
			'nonce'  => 'bp_push_notification_settings',
			'attributes' => array(
				'name'  => 'push_notification-settings-submit',
				'id'    => 'submit',
				'value' => __( 'Save Changes', 'buddypress-for-pwaforwp' ),
				'class' => 'auto',
			),
		);
	return $buttons;
}
//Current User ID
$user_id = bp_displayed_user_id();
//Get push notification settings.
$bppn_pwa_settings = bp_get_user_meta( $user_id, 'bp_push_notification_setting', true );
$defaultsettings = BP_basic_setup::pn_defaultValues();
$bppn_pwa_settings = wp_parse_args($bppn_pwa_settings, $defaultsettings);

bp_nouveau_member_hook( 'before', 'settings_template' ); ?>

<h2 class="screen-heading profile-settings-screen">
	<?php esc_html_e( 'Push notifications', 'buddypress-for-pwaforwp' ); ?>
</h2>
<p class="bp-help-text email-notifications-info">Set your push notifications preferences.</p>
<form action="<?php echo esc_url( bp_displayed_user_domain() . bp_get_settings_slug() . '/push-notification/' ); ?>" method="post" class="standard-form" id="settings-form">

	<?php //bp_nouveau_member_email_notice_settings(); ?>
	<table class="notification-settings" id="friends-notification-settings">
		<thead>
			<tr>
				<th class="icon"></th>
				<th class="title"><?php echo esc_html__('General', 'buddypress-for-pwaforwp'); ?></th>
				<th class="yes"><?php echo esc_html__('Yes', 'buddypress-for-pwaforwp'); ?></th>
				<th class="no"><?php echo esc_html__('No', 'buddypress-for-pwaforwp'); ?></th>
			</tr>
		</thead>
		<tbody>
			<tr id="friends-notification-settings-request">
				<td></td>
				<td><?php printf( __( 'When any member mentions tags in messages "@%s" ?', 'buddypress-for-pwaforwp' ), bp_core_get_username( bp_displayed_user_id() ) ); ?></td>
				<td class="yes">
					<input type="radio" name="push_notifications[notification_allow_request]" id="push-notification-allow-request-yes" value="yes" <?php checked( $bppn_pwa_settings['notification_allow_request'], 'yes', true ) ?>>
					<label for="notification-friends-friendship-request-yes" class="bp-screen-reader-text"><?php echo esc_html__('Yes, send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
				<td class="no">
					<input type="radio" name="push_notifications[notification_allow_request]" id="notification-friends-friendship-request-no" value="no" <?php checked( $bppn_pwa_settings['notification_allow_request'], 'no', true ) ?>>
					<label for="notification-friends-friendship-request-no" class="bp-screen-reader-text"><?php echo esc_html__('No, do not send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
			</tr>
			<tr id="friends-notification-settings-request">
				<td></td>
				<td><?php echo esc_html__('Member replies to an update or comment you\'ve posted', 'buddypress-for-pwaforwp'); ?></td>
				<td class="yes">
					<input type="radio" name="push_notifications[notification_new_reply]" id="push-notification-allow-request-yes" value="yes" <?php checked( $bppn_pwa_settings['notification_new_reply'], 'yes', true ) ?>>
					<label for="notification-friends-friendship-request-yes" class="bp-screen-reader-text"><?php echo esc_html__('Yes, send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
				<td class="no">
					<input type="radio" name="push_notifications[notification_new_reply]" id="notification-friends-friendship-request-no" value="no" <?php checked( $bppn_pwa_settings['notification_new_reply'], 'no', true ) ?>>
					<label for="notification-friends-friendship-request-no" class="bp-screen-reader-text"><?php echo esc_html__('No, do not send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
			</tr>
			<tr id="friends-notification-settings-request">
				<td></td>
				<td><?php echo esc_html__('Member sends you a new message', 'buddypress-for-pwaforwp'); ?></td>
				<td class="yes">
					<input type="radio" name="push_notifications[notification_new_message]" id="push-notification-allow-request-yes" value="yes" <?php checked( $bppn_pwa_settings['notification_new_message'], 'yes', true ) ?>>
					<label for="notification-friends-friendship-request-yes" class="bp-screen-reader-text"><?php echo esc_html__('Yes, send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
				<td class="no">
					<input type="radio" name="push_notifications[notification_new_message]" id="notification-friends-friendship-request-no" value="no" <?php checked( $bppn_pwa_settings['notification_new_message'], 'no', true ) ?>>
					<label for="notification-friends-friendship-request-no" class="bp-screen-reader-text"><?php echo esc_html__('No, do not send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
			</tr>
			<!-- Friends -->
			<tr id="friends-notification-settings-request">
				<td></td>
				<td><?php echo esc_html__('Member sends you a friendship request', 'buddypress-for-pwaforwp'); ?></td>
				<td class="yes">
					<input type="radio" name="push_notifications[friends_friendship_request]" id="push-notification-allow-request-yes" value="yes" <?php checked( $bppn_pwa_settings['friends_friendship_request'], 'yes', true ) ?>>
					<label for="notification-friends-friendship-request-yes" class="bp-screen-reader-text"><?php echo esc_html__('Yes, send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
				<td class="no">
					<input type="radio" name="push_notifications[friends_friendship_request]" id="notification-friends-friendship-request-no" value="no" <?php checked( $bppn_pwa_settings['friends_friendship_request'], 'no', true ) ?>>
					<label for="notification-friends-friendship-request-no" class="bp-screen-reader-text"><?php echo esc_html__('No, do not send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
			</tr>
			<tr id="friends-notification-settings-request">
				<td></td>
				<td><?php echo esc_html__('Member accepts your friendship request', 'buddypress-for-pwaforwp'); ?></td>
				<td class="yes">
					<input type="radio" name="push_notifications[friends_friendship_accepted]" id="push-notification-allow-request-yes" value="yes" <?php checked( $bppn_pwa_settings['friends_friendship_accepted'], 'yes', true ) ?>>
					<label for="notification-friends-friendship-request-yes" class="bp-screen-reader-text"><?php echo esc_html__('Yes, send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
				<td class="no">
					<input type="radio" name="push_notifications[friends_friendship_accepted]" id="notification-friends-friendship-request-no" value="no" <?php checked( $bppn_pwa_settings['friends_friendship_accepted'], 'no', true ) ?>>
					<label for="notification-friends-friendship-request-no" class="bp-screen-reader-text"><?php echo esc_html__('No, do not send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
			</tr>

			<!-- Groups -->
			<tr id="friends-notification-settings-request">
				<td></td>
				<td><?php echo esc_html__('Member invites you to join a group', 'buddypress-for-pwaforwp'); ?></td>
				<td class="yes">
					<input type="radio" name="push_notifications[groups_invite]" id="push-notification-allow-request-yes" value="yes" <?php checked( $bppn_pwa_settings['groups_invite'], 'yes', true ) ?>>
					<label for="notification-friends-friendship-request-yes" class="bp-screen-reader-text"><?php echo esc_html__('Yes, send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
				<td class="no">
					<input type="radio" name="push_notifications[groups_invite]" id="notification-friends-friendship-request-no" value="no" <?php checked( $bppn_pwa_settings['groups_invite'], 'no', true ) ?>>
					<label for="notification-friends-friendship-request-no" class="bp-screen-reader-text"><?php echo esc_html__('No, do not send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
			</tr>
			<tr id="friends-notification-settings-request">
				<td></td>
				<td><?php echo esc_html__('Group information is updated	', 'buddypress-for-pwaforwp'); ?></td>
				<td class="yes">
					<input type="radio" name="push_notifications[groups_group_updated]" id="push-notification-allow-request-yes" value="yes" <?php checked( $bppn_pwa_settings['groups_group_updated'], 'yes', true ) ?>>
					<label for="notification-friends-friendship-request-yes" class="bp-screen-reader-text"><?php echo esc_html__('Yes, send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
				<td class="no">
					<input type="radio" name="push_notifications[groups_group_updated]" id="notification-friends-friendship-request-no" value="no" <?php checked( $bppn_pwa_settings['groups_group_updated'], 'no', true ) ?>>
					<label for="notification-friends-friendship-request-no" class="bp-screen-reader-text"><?php echo esc_html__('No, do not send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
			</tr>
			<tr id="friends-notification-settings-request">
				<td></td>
				<td><?php echo esc_html__('When you are promoted to a group administrator or moderator', 'buddypress-for-pwaforwp'); ?></td>
				<td class="yes">
					<input type="radio" name="push_notifications[groups_admin_promotion]" id="push-notification-allow-request-yes" value="yes" <?php checked( $bppn_pwa_settings['groups_admin_promotion'], 'yes', true ) ?>>
					<label for="notification-friends-friendship-request-yes" class="bp-screen-reader-text"><?php echo esc_html__('Yes, send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
				<td class="no">
					<input type="radio" name="push_notifications[groups_admin_promotion]" id="notification-friends-friendship-request-no" value="no" <?php checked( $bppn_pwa_settings['groups_admin_promotion'], 'no', true ) ?>>
					<label for="notification-friends-friendship-request-no" class="bp-screen-reader-text"><?php echo esc_html__('No, do not send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
			</tr>
			<tr id="friends-notification-settings-request">
				<td></td>
				<td><?php echo esc_html__('Member requests to join a private group for which you are an admin', 'buddypress-for-pwaforwp'); ?></td>
				<td class="yes">
					<input type="radio" name="push_notifications[groups_membership_request]" id="push-notification-allow-request-yes" value="yes" <?php checked( $bppn_pwa_settings['groups_membership_request'], 'yes', true ) ?>>
					<label for="notification-friends-friendship-request-yes" class="bp-screen-reader-text"><?php echo esc_html__('Yes, send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
				<td class="no">
					<input type="radio" name="push_notifications[groups_membership_request]" id="notification-friends-friendship-request-no" value="no" <?php checked( $bppn_pwa_settings['groups_membership_request'], 'no', true ) ?>>
					<label for="notification-friends-friendship-request-no" class="bp-screen-reader-text"><?php echo esc_html__('No, do not send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
			</tr>
			<tr id="friends-notification-settings-request">
				<td></td>
				<td><?php echo esc_html__('Your request to join a group has been approved or denied', 'buddypress-for-pwaforwp'); ?></td>
				<td class="yes">
					<input type="radio" name="push_notifications[membership_request_completed]" id="push-notification-allow-request-yes" value="yes" <?php checked( $bppn_pwa_settings['membership_request_completed'], 'yes', true ) ?>>
					<label for="notification-friends-friendship-request-yes" class="bp-screen-reader-text"><?php echo esc_html__('Yes, send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
				<td class="no">
					<input type="radio" name="push_notifications[membership_request_completed]" id="notification-friends-friendship-request-no" value="no" <?php checked( $bppn_pwa_settings['membership_request_completed'], 'no', true ) ?>>
					<label for="notification-friends-friendship-request-no" class="bp-screen-reader-text"><?php echo esc_html__('No, do not send email', 'buddypress-for-pwaforwp'); ?></label>
				</td>
			</tr>

			

			
		</tbody>
	</table>

	<?php bp_nouveau_submit_button( 'member-push-notification-settings' ); ?>
</form>
<?php
bp_nouveau_member_hook( 'after', 'settings_template' );