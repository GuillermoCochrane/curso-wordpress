__( 'Triggers', 'elementor-pro' );
__( 'Advanced Rules', 'elementor-pro' );
__( 'Display Conditions', 'elementor-pro' );